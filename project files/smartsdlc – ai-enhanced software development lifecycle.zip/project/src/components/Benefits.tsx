import React from 'react';
import { CheckCircle, TrendingUp, Clock, DollarSign } from 'lucide-react';

const Benefits = () => {
  const benefits = [
    {
      icon: <Clock className="w-8 h-8 text-blue-600" />,
      title: "Faster Time-to-Market",
      description: "Reduce development cycles by up to 60% with AI-powered automation and intelligent code generation.",
      stats: "60% faster delivery"
    },
    {
      icon: <DollarSign className="w-8 h-8 text-emerald-600" />,
      title: "Cost Optimization",
      description: "Lower development costs through reduced manual effort and fewer production issues.",
      stats: "40% cost reduction"
    },
    {
      icon: <TrendingUp className="w-8 h-8 text-purple-600" />,
      title: "Quality Improvement",
      description: "Achieve higher code quality with AI-driven reviews, testing, and continuous monitoring.",
      stats: "90% fewer bugs"
    },
    {
      icon: <CheckCircle className="w-8 h-8 text-green-600" />,
      title: "Enhanced Productivity",
      description: "Empower your team with AI assistants that handle routine tasks and provide intelligent insights.",
      stats: "3x productivity boost"
    }
  ];

  return (
    <section id="benefits" className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Measurable Business Impact
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            See real results from day one with our AI-enhanced development platform
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {benefits.map((benefit, index) => (
            <div 
              key={index}
              className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300 border border-gray-100"
            >
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0">
                  {benefit.icon}
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-semibold mb-2 text-gray-900">{benefit.title}</h3>
                  <p className="text-gray-600 mb-4 leading-relaxed">{benefit.description}</p>
                  <div className="inline-flex items-center px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                    {benefit.stats}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <div className="bg-white p-8 rounded-xl shadow-lg border border-gray-100">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Join 1,000+ Companies Already Transforming Their SDLC</h3>
            <p className="text-gray-600 mb-6">From startups to Fortune 500 companies, teams worldwide trust SmartSDLC</p>
            <div className="flex flex-wrap justify-center gap-8 items-center opacity-60">
              <div className="w-24 h-12 bg-gray-200 rounded"></div>
              <div className="w-24 h-12 bg-gray-200 rounded"></div>
              <div className="w-24 h-12 bg-gray-200 rounded"></div>
              <div className="w-24 h-12 bg-gray-200 rounded"></div>
              <div className="w-24 h-12 bg-gray-200 rounded"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Benefits;