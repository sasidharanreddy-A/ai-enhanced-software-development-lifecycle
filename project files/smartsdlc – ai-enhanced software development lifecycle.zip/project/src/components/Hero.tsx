import React from 'react';
import { ArrowRight, Zap, Shield, TrendingUp } from 'lucide-react';

const Hero = () => {
  return (
    <section className="pt-20 pb-16 bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            AI-Enhanced
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent block">
              Software Development
            </span>
            Lifecycle
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
            Transform your development process with intelligent automation, predictive analytics, 
            and AI-powered insights that accelerate delivery while maintaining the highest quality standards.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-8 py-4 rounded-lg hover:shadow-xl transition-all duration-200 transform hover:scale-105 flex items-center justify-center space-x-2">
              <span>Start Free Trial</span>
              <ArrowRight className="w-5 h-5" />
            </button>
            <button className="border-2 border-gray-300 text-gray-700 px-8 py-4 rounded-lg hover:border-blue-600 hover:text-blue-600 transition-all duration-200">
              Watch Demo
            </button>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mt-16">
          <div className="text-center p-6 bg-white/50 backdrop-blur-sm rounded-xl border border-gray-200 hover:shadow-lg transition-all duration-200">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <Zap className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-semibold mb-2">3x Faster Development</h3>
            <p className="text-gray-600">AI-powered code generation and automated testing reduce development time significantly.</p>
          </div>

          <div className="text-center p-6 bg-white/50 backdrop-blur-sm rounded-xl border border-gray-200 hover:shadow-lg transition-all duration-200">
            <div className="w-16 h-16 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <Shield className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-semibold mb-2">90% Fewer Bugs</h3>
            <p className="text-gray-600">Intelligent code analysis and predictive testing catch issues before they reach production.</p>
          </div>

          <div className="text-center p-6 bg-white/50 backdrop-blur-sm rounded-xl border border-gray-200 hover:shadow-lg transition-all duration-200">
            <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <TrendingUp className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-semibold mb-2">200% ROI</h3>
            <p className="text-gray-600">Maximize your development investment with AI-driven efficiency and quality improvements.</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;