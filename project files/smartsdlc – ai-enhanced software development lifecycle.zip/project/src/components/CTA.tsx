import React from 'react';
import { ArrowRight, CheckCircle } from 'lucide-react';

const CTA = () => {
  const features = [
    "30-day free trial",
    "No credit card required",
    "Full feature access",
    "24/7 support included"
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-blue-600 via-purple-600 to-blue-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Ready to Transform Your Development Process?
          </h2>
          <p className="text-xl text-blue-100 mb-8 leading-relaxed">
            Join thousands of development teams who've already accelerated their delivery with AI-enhanced SDLC.
          </p>
          
          <div className="grid md:grid-cols-2 gap-4 mb-8">
            {features.map((feature, index) => (
              <div key={index} className="flex items-center justify-center md:justify-start space-x-2 text-blue-100">
                <CheckCircle className="w-5 h-5 text-green-400" />
                <span>{feature}</span>
              </div>
            ))}
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-white text-blue-600 px-8 py-4 rounded-lg font-semibold hover:bg-gray-100 transition-all duration-200 transform hover:scale-105 flex items-center justify-center space-x-2">
              <span>Start Free Trial</span>
              <ArrowRight className="w-5 h-5" />
            </button>
            <button className="border-2 border-white text-white px-8 py-4 rounded-lg hover:bg-white hover:text-blue-600 transition-all duration-200">
              Schedule Demo
            </button>
          </div>

          <p className="text-blue-200 text-sm mt-6">
            Questions? Contact our team at{' '}
            <a href="mailto:hello@smartsdlc.com" className="text-white underline hover:no-underline">
              hello@smartsdlc.com
            </a>
          </p>
        </div>
      </div>
    </section>
  );
};

export default CTA;