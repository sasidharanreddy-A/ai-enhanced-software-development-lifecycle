import React from 'react';
import { Code, TestTube, GitBranch, Brain, Shield, BarChart3, Users, Workflow } from 'lucide-react';

const Features = () => {
  const features = [
    {
      icon: <Brain className="w-6 h-6" />,
      title: "AI Code Generation",
      description: "Generate high-quality code from natural language descriptions with context-aware AI."
    },
    {
      icon: <TestTube className="w-6 h-6" />,
      title: "Intelligent Testing",
      description: "Automated test generation, execution, and maintenance powered by machine learning."
    },
    {
      icon: <GitBranch className="w-6 h-6" />,
      title: "Smart Version Control",
      description: "AI-assisted code reviews, conflict resolution, and merge recommendations."
    },
    {
      icon: <Shield className="w-6 h-6" />,
      title: "Security Analysis",
      description: "Continuous security scanning with AI-powered vulnerability detection and fixes."
    },
    {
      icon: <BarChart3 className="w-6 h-6" />,
      title: "Predictive Analytics",
      description: "Forecast project timelines, identify bottlenecks, and optimize resource allocation."
    },
    {
      icon: <Users className="w-6 h-6" />,
      title: "Team Collaboration",
      description: "AI-enhanced communication tools and intelligent task assignment."
    },
    {
      icon: <Workflow className="w-6 h-6" />,
      title: "Process Optimization",
      description: "Continuously improve workflows based on AI analysis of development patterns."
    },
    {
      icon: <Code className="w-6 h-6" />,
      title: "Code Quality",
      description: "Automated code reviews, refactoring suggestions, and quality metrics tracking."
    }
  ];

  return (
    <section id="features" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Comprehensive AI-Powered Features
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Every aspect of your software development lifecycle enhanced with cutting-edge artificial intelligence
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="group p-6 bg-gray-50 rounded-xl hover:bg-white hover:shadow-lg transition-all duration-300 border border-gray-100"
            >
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center text-white mb-4 group-hover:scale-110 transition-transform duration-200">
                {feature.icon}
              </div>
              <h3 className="text-lg font-semibold mb-2 text-gray-900">{feature.title}</h3>
              <p className="text-gray-600 text-sm leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;