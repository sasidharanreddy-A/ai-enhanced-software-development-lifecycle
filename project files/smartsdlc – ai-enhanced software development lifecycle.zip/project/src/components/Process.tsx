import React from 'react';
import { ArrowRight, PenTool, Code, TestTube, Rocket, Monitor } from 'lucide-react';

const Process = () => {
  const steps = [
    {
      icon: <PenTool className="w-6 h-6" />,
      title: "Plan & Design",
      description: "AI-powered requirement analysis and architecture recommendations",
      color: "from-blue-500 to-blue-600"
    },
    {
      icon: <Code className="w-6 h-6" />,
      title: "Develop",
      description: "Intelligent code generation, real-time suggestions, and automated refactoring",
      color: "from-emerald-500 to-emerald-600"
    },
    {
      icon: <TestTube className="w-6 h-6" />,
      title: "Test",
      description: "Automated test generation, execution, and quality assurance",
      color: "from-purple-500 to-purple-600"
    },
    {
      icon: <Rocket className="w-6 h-6" />,
      title: "Deploy",
      description: "Smart deployment strategies and automated rollback capabilities",
      color: "from-orange-500 to-orange-600"
    },
    {
      icon: <Monitor className="w-6 h-6" />,
      title: "Monitor",
      description: "Continuous monitoring with predictive analytics and performance optimization",
      color: "from-pink-500 to-pink-600"
    }
  ];

  return (
    <section id="process" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            AI-Enhanced Development Process
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Every phase of your SDLC optimized with artificial intelligence
          </p>
        </div>

        <div className="relative">
          {/* Desktop Flow */}
          <div className="hidden md:flex items-center justify-between mb-8">
            {steps.map((step, index) => (
              <React.Fragment key={index}>
                <div className="flex flex-col items-center">
                  <div className={`w-16 h-16 rounded-full bg-gradient-to-br ${step.color} flex items-center justify-center text-white mb-4 shadow-lg`}>
                    {step.icon}
                  </div>
                  <div className="text-center">
                    <h3 className="font-semibold text-gray-900 mb-1">{step.title}</h3>
                    <p className="text-sm text-gray-600 max-w-32">{step.description}</p>
                  </div>
                </div>
                {index < steps.length - 1 && (
                  <ArrowRight className="w-6 h-6 text-gray-400 mx-4" />
                )}
              </React.Fragment>
            ))}
          </div>

          {/* Mobile Flow */}
          <div className="md:hidden space-y-6">
            {steps.map((step, index) => (
              <div key={index} className="flex items-start space-x-4">
                <div className={`w-12 h-12 rounded-full bg-gradient-to-br ${step.color} flex items-center justify-center text-white shadow-lg flex-shrink-0`}>
                  {step.icon}
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-1">{step.title}</h3>
                  <p className="text-sm text-gray-600">{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-16 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl p-8 text-white text-center">
          <h3 className="text-2xl font-bold mb-4">Ready to Transform Your Development Process?</h3>
          <p className="text-blue-100 mb-6">Experience the power of AI-enhanced SDLC with a free 30-day trial</p>
          <button className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors">
            Start Your Free Trial
          </button>
        </div>
      </div>
    </section>
  );
};

export default Process;